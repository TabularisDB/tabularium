# turbosmtp

Modern, runtime-agnostic TypeScript client for the [turboSMTP v2 API](https://serversmtp.com/email-api-for-developers).

- **ESM-only**, **zero runtime dependencies** — built on the platform `fetch`.
- Runs on **Node 20.19+, Deno, Bun, browsers, and edge runtimes**.
- Fully typed, resource-namespaced API (`client.mail.send()`), **throw-based typed errors**, and **auto-paginating** list endpoints.
- Preserves **64-bit ids** (`mid`, analytics `id`, …) exactly — no silent precision loss.
- A faithful TypeScript port of [`turbosmtp-rs`](../turbosmtp-rs), generated against the official OpenAPI spec.

> Status: early development (`0.1.0`).

## Install

```sh
npm install turbosmtp
# pnpm add turbosmtp · bun add turbosmtp · deno add npm:turbosmtp
```

## Quick start

```ts
import { TurboSmtp } from "turbosmtp";

const client = new TurboSmtp({
  apiKey: process.env.TURBOSMTP_API_KEY,        // for everything except mail send
  consumer: {                                    // required for mail send
    key: process.env.TURBOSMTP_CONSUMER_KEY!,
    secret: process.env.TURBOSMTP_CONSUMER_SECRET!,
  },
  region: "global",                              // "global" | "eu"
});

const { mid } = await client.mail.send({
  from: "Acme <hello@acme.com>",
  to: "user@example.com",
  subject: "Welcome",
  html_content: "<h1>Hi!</h1>",
});
console.log("sent", mid); // 64-bit id, returned as an exact string
```

## Authentication

turboSMTP has two auth modes; configure whichever you need (or both):

| Mode | Header(s) | Used by |
| --- | --- | --- |
| **Consumer key/secret** | `consumerKey`, `consumerSecret` | `mail.send()` only |
| **API key** | `Authorization` | every other endpoint |

Calling an endpoint without the credential it requires throws `UnsupportedAuthError`
before any network call. Obtain an API key by logging in, and create consumer
key/secret pairs with `consumerKeys.create()`:

```ts
const { auth } = await client.auth.authorize("you@acme.com", "password");
const authed = new TurboSmtp({ apiKey: auth });

const created = await authed.consumerKeys.create("my-app"); // secret shown once!
const sender = new TurboSmtp({ consumer: { key: created.consumer_key, secret: created.consumer_secret } });
```

## Error handling

Every failure is an instance of `TurboSmtpError`. HTTP failures are
`APIStatusError` subclasses carrying `status`, parsed `messages`, `code`, and
`requestId`; transport failures are `APIConnectionError` / `APIConnectionTimeoutError`.

```ts
import { TurboSmtp, NotFoundError, RateLimitError, APIStatusError } from "turbosmtp";

try {
  await client.analytics.get("999999999999999999");
} catch (err) {
  if (err instanceof NotFoundError) console.warn("no such message");
  else if (err instanceof RateLimitError) console.warn("slow down");
  else if (err instanceof APIStatusError) console.error(err.status, err.messages, err.requestId);
  else throw err;
}
```

The client automatically retries transient failures (network errors, `429`, and
`5xx` on idempotent methods) with exponential backoff honoring `Retry-After`.
Tune via `maxRetries` / `timeout` (client-wide) or per call:

```ts
await client.suppressions.list({ from, to }, { timeout: 5000, maxRetries: 0, signal });
```

## Pagination

List endpoints return a `Page<T>` that is async-iterable and fetches subsequent
pages transparently:

```ts
const page = await client.analytics.list({ from: "2026-01-01", to: "2026-01-31" });

console.log(page.count, page.results.length); // first page
for await (const item of page) {              // auto-paginates across all pages
  console.log(item.id, item.status);
}
const all = await client.analytics.list({ from, to }).then((p) => p.collect());
```

## Resource overview

```ts
await client.mail.send({ from, to, subject, html_content });
await client.auth.authorize(email, password);
await client.suppressions.list({ from, to });
await client.suppressions.bulkDelete(["a@x.com", "b@x.com"]);
await client.analytics.list({ from, to, "status[]": ["SUCCESS", "FAIL"] });
await client.alerts.create({ email: "ops@acme.com", percentage: 10 });
await client.emailValidation.validateEmail({ email: "test@acme.com" });
await client.subaccounts.list({ page: 1, limit: 50 });
await client.billing.buyEmailValidationCredits(50);
await client.meta.countries();
await client.consumerKeys.list();
```

Every list method returns a `Page<T>`; every method accepts an optional trailing
`RequestOptions` (`{ timeout, maxRetries, signal, headers }`).

## Webhooks

The `turbosmtp/webhooks` entry point is standalone (it pulls in none of the HTTP
client) and works in any runtime:

```ts
import { handleWebhookRequest } from "turbosmtp/webhooks";

// Hono / h3 / Deno / Bun / Workers / Next.js route handler:
export const POST = (request: Request) =>
  handleWebhookRequest(request, (event) => {
    switch (event.kind.type) {
      case "delivered": console.log("delivered", event.mid); break;
      case "bounce":    console.warn("bounce", event.kind.reason.response); break;
      case "click":     console.log("click", event.kind.url); break;
    }
  });
```

```ts
// Plain Node http server:
import { createServer } from "node:http";
import { createNodeWebhookListener } from "turbosmtp/webhooks";

createServer(createNodeWebhookListener((e) => console.log(e.kind.type))).listen(3000);
```

Or parse a raw payload yourself with `parseWebhookEvent` / `parseWebhookEvents`.

## Runtime support

Built entirely on the platform `fetch`, `AbortSignal`, and `FormData`. Works on
Node 20.19+, Deno, Bun, modern browsers, and edge runtimes. CommonJS consumers on
Node 20.19+ can `require()` it (via `require(esm)`) or use dynamic `import()`. You
can inject a custom `fetch` via the `fetch` option.

## Development

```sh
pnpm install
pnpm test         # vitest + MSW
pnpm typecheck    # tsc --noEmit
pnpm build        # tsdown -> dist/ (ESM + .d.ts + source maps)
pnpm verify-pack  # publint + are-the-types-wrong (esm-only profile)
pnpm fix          # biome lint + format (autofix)
```

## License

MIT
